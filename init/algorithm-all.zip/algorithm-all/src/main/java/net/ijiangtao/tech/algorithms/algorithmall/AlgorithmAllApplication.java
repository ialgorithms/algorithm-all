package net.ijiangtao.tech.algorithms.algorithmall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgorithmAllApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlgorithmAllApplication.class, args);
	}

}

